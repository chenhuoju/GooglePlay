package com.chj.actionbar;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.view.ActionMode;
import android.support.v7.view.ActionMode.Callback;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

/**
 * @包名: com.chj.actionbar
 * @类名: MainActivity
 * @作者: 陈火炬
 * @创建时间 : 2015-8-23 下午9:30:37
 * 
 * @描述: ActionMode(操作模式)的使用
 * 
 * @SVN版本: $Rev$
 * @更新人: $Author$
 * @更新时间: $Date$
 * 
 * @更新描述:
 */
public class ActionModeActivity extends ActionBarActivity implements Callback
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_mode);
	}

	public void clickActionMode(View view)
	{
		// startActionMode(null);//低版本使用的
		startSupportActionMode(this);// 兼容高低版本
	}

	/**
	 * 原始， 新建menu时调用；后来，新建SupportV7 actionBar时调用
	 */
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		getMenuInflater().inflate(R.menu.mode, menu);
		return true;
	}

	/**
	 * 弹吐司的方法
	 * 
	 * @param msg
	 */
	private void toast(String msg)
	{
		Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
	}

	/**
	 * 当创建actionMode时，和 onCreateOptionsMenu操作是一样的
	 */
	@Override
	public boolean onCreateActionMode(ActionMode mode, Menu menu)
	{
		getMenuInflater().inflate(R.menu.mode, menu);

		return true;
	}

	/**
	 * 刷新ActionMode时调用
	 */
	@Override
	public boolean onPrepareActionMode(ActionMode mode, Menu menu)
	{
		return false;
	}

	/**
	 * 对actionItem进行操作，相当于onOptionsItemSelected
	 */
	@Override
	public boolean onActionItemClicked(ActionMode mode, MenuItem item)
	{
		int itemId = item.getItemId();

		switch (itemId)
		{
			case R.id.mode_1:
				toast("mode_1");
				break;
			case R.id.mode_2:
				toast("mode_2");
				break;
			case R.id.mode_3:
				toast("mode_3");
				break;
			case R.id.mode_4:
				toast("mode_4");
				break;
			case R.id.mode_5:
				toast("mode_5");

				break;
			default:
				break;
		}

		return true;
	}

	/**
	 * 销毁ActionMode时调用
	 */
	@Override
	public void onDestroyActionMode(ActionMode mode)
	{

	}

}
