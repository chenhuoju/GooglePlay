package com.chj.actionbar;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.internal.view.SupportMenuItem;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.SearchView.OnCloseListener;
import android.support.v7.widget.SearchView.OnQueryTextListener;
import android.support.v7.widget.SearchView.OnSuggestionListener;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

/**
 * @包名: com.chj.actionbar
 * @类名: MainActivity
 * @作者: 陈火炬
 * @创建时间 : 2015-8-23 下午9:30:37
 * 
 * @描述: ActionBar的使用
 * 
 * @SVN版本: $Rev$
 * @更新人: $Author$
 * @更新时间: $Date$
 * 
 * @更新描述:
 */
public class MainActivity extends ActionBarActivity implements OnFocusChangeListener, OnQueryTextListener, OnClickListener, OnSuggestionListener, OnCloseListener
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	/**
	 * 原始， 新建menu时调用；后来，新建SupportV7 actionBar时调用
	 */
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	// item点击时的操作
	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		int itemId = item.getItemId();

		// View actionView = item.getActionView();//只能高版本使用的
		SupportMenuItem menuItem = (SupportMenuItem) item;
		View actionView = menuItem.getActionView();// 兼容低版本使用

		switch (itemId)
		{
			case R.id.action_1:
				toast("action_1");
				break;
			case R.id.action_2:
				toast("action_2");
				break;
			case R.id.action_3:
				toast("action_3");
				break;
			case R.id.action_4:
				toast("action_4");
				break;
			case R.id.action_5:
				toast("action_5");

				SearchView searchView = (SearchView) actionView;

				// searchView常用的监听方法
				searchView.setOnQueryTextFocusChangeListener(this);
				searchView.setOnQueryTextListener(this);
				searchView.setOnSearchClickListener(this);
				searchView.setOnSuggestionListener(this);
				searchView.setOnCloseListener(this);

				searchView.setSuggestionsAdapter(null);

				break;
			default:
				break;
		}

		return super.onOptionsItemSelected(item);
	}

	/**
	 * 弹吐司的方法
	 * 
	 * @param msg
	 */
	private void toast(String msg)
	{
		Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
	}

	/**
	 * 文本焦点失去时的操作
	 */
	@Override
	public void onFocusChange(View v, boolean hasFocus)
	{
		// 软件盘隐藏
		InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.hideSoftInputFromWindow(getCurrentFocus().getApplicationWindowToken(), 0);
	}

	/**
	 * 提交查询时
	 */
	@Override
	public boolean onQueryTextSubmit(String query)
	{
		return false;
	}

	/**
	 * 文本改变时
	 */
	@Override
	public boolean onQueryTextChange(String newText)
	{
		return false;
	}

	/**
	 * 软件盘上查询按钮点击事件
	 */
	@Override
	public void onClick(View arg0)
	{

	}

	/**
	 * searchView关闭时的回调
	 */
	@Override
	public boolean onClose()
	{
		return false;
	}

	/**
	 * 查询结果条目的
	 */
	@Override
	public boolean onSuggestionSelect(int position)
	{
		return false;
	}

	/**
	 * 点击查询结果条目的
	 */
	@Override
	public boolean onSuggestionClick(int position)
	{
		return false;
	}

}
