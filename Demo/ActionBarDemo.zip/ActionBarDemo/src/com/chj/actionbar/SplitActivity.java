package com.chj.actionbar;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

/**
 * @包名: com.chj.actionbar
 * @类名: MainActivity
 * @作者: 陈火炬
 * @创建时间 : 2015-8-23 下午9:30:37
 * 
 * @描述: 分段的ActionBar
 * 
 * @SVN版本: $Rev$
 * @更新人: $Author$
 * @更新时间: $Date$
 * 
 * @更新描述:
 */
public class SplitActivity extends ActionBarActivity
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	/**
	 * 原始， 新建menu时调用；后来，新建SupportV7 actionBar时调用
	 */
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		getMenuInflater().inflate(R.menu.split, menu);
		return true;
	}

	// item点击时的操作
	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		int itemId = item.getItemId();

		switch (itemId)
		{
			case R.id.split_1:
				toast("split_1");
				break;
			case R.id.split_2:
				toast("split_2");
				break;
			case R.id.split_3:
				toast("split_3");
				break;
			case R.id.split_4:
				toast("split_4");
				break;
			case R.id.split_5:
				toast("split_5");

				break;
			default:
				break;
		}

		return super.onOptionsItemSelected(item);
	}

	/**
	 * 弹吐司的方法
	 * 
	 * @param msg
	 */
	private void toast(String msg)
	{
		Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
	}

}
